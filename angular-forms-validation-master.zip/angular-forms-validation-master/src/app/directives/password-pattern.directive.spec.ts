import { PasswordPatternDirective } from './password-pattern.directive';

describe('PasswordPatternDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordPatternDirective();
    expect(directive).toBeTruthy();
  });
});
